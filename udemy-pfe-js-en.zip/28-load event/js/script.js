
window.addEventListener('load', function() {
    console.log('the page has been loaded!');    
});